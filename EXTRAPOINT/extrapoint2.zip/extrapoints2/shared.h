#define XSPD 1
#define YSPD 1
#define x_pause 100
#define y_pause 150