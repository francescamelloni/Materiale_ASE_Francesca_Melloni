#include <LPC17xx.h>                  /* LPC17xx definitions */
#include "CAN.h"                      /* LPC17xx CAN adaption layer */
#include "../GLCD/GLCD.h"
#include "stdio.h"

extern uint8_t icr ; 										//icr and result must be global in order to work with both real and simulated landtiger.
extern uint32_t result;
extern CAN_msg       CAN_TxMsg;    /* CAN message for sending */
extern CAN_msg       CAN_RxMsg;    /* CAN message for receiving */                                

int readtime, readlives, readscore;

/*----------------------------------------------------------------------------
  CAN interrupt handler
 ----------------------------------------------------------------------------*/
void CAN_IRQHandler (void)  {

  /* check CAN controller 1 */
	icr = 0;
  icr = (LPC_CAN1->ICR | icr) & 0xFF;               /* clear interrupts */
	icr = (LPC_CAN2->ICR | icr) & 0xFF;             /* clear interrupts */
	
	extern int gameover;

	
  if (icr & (1 << 0)) {                          		/* CAN Controller #1 meassage is received */
		CAN_rdMsg (1, &CAN_RxMsg);	                		/* Read the message */
    LPC_CAN1->CMR = (1 << 2);                    		/* Release receive buffer */
		
		readlives = CAN_RxMsg.data[0];
		readtime = (CAN_RxMsg.data[1])  ;
		
		readscore = (CAN_RxMsg.data[2] << 8);
		readscore = readscore | CAN_RxMsg.data[3];
		
		char stringscore[18];
		sprintf(stringscore, "%d", readscore);
		char stringtime[14];
		
		if(readtime > 10){
			sprintf(stringtime, "%d", readtime);
		}
		else{
			sprintf(stringtime, "%d ", readtime);
		}
		
		GUI_Text(0, 0, (uint8_t *) stringtime, White, Black);
		GUI_Text(140, 15, (uint8_t *) stringscore, White, Black);
		
		if(!gameover){
				displayLives(readlives);
			}
		
		}
	}
