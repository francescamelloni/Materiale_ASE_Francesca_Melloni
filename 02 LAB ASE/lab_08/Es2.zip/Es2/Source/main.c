
// Importiamo i dati e le funzioni dall'Assembly
extern int Matrix_Coordinates[];
extern char ROWS;
extern char COLUMNS;

extern int check_square(int x, int y, int r);
extern float my_division(float* a, float* b);

int main(void) {
	float raggio = 3;
	volatile float pi_greco = 0; // qui stava l'errore: doveva essere dichiarata
	//come volatile per farla mantenere in memoria e poterla visualizzare
	float area=0; 
	int dim=ROWS*COLUMNS;
	int i=0, x, y;
	for(i=0;i<dim;i=i+2){
		x=Matrix_Coordinates[i];
		y=Matrix_Coordinates[i+1];
		if (check_square(x, y, raggio)) {
				area++;
		}
	}
	float r2= raggio*raggio;
	pi_greco=my_division((& area), &(r2));

  while(1);
}
