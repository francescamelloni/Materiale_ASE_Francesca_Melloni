extern int call_svc(void);
int main(void){
  call_svc();
	
  while(1);
}